package softuni.exam.common;

public class Constants {

    public static final String INVALID_INPUT = "Invalid %s";

    public static final String SUCCESSFUL_INPUT = "Successfully imported %s: %s";

}
