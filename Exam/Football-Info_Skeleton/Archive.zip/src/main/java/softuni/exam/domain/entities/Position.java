package softuni.exam.domain.entities;

public enum Position {
    GK,
    RB,
    LB,
    CM,
    RM,
    LM,
    LW,
    RW,
    ST
}
