create definer = root@localhost view v_groups_avg_wand_size as
select `w`.`deposit_group` AS `deposit_group`, avg(`w`.`magic_wand_size`) AS `Average Wand Size`
from `gringotts`.`wizzard_deposits` `w`
group by `w`.`deposit_group`
order by `Average Wand Size`;

