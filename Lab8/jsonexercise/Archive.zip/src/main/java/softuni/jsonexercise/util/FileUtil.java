package softuni.jsonexercise.util;

import java.io.FileNotFoundException;
import java.io.IOException;

public interface FileUtil {

    String fileContent(String filePath) throws IOException;
}
