create
    definer = root@localhost function udf_calculate_following(user_id int) returns int
BEGIN
	
    DECLARE following_count INT;
    SET following_count = (SELECT COUNT(*) FROM users_followers uf WHERE uf.follower_id = user_id);
    RETURN following_count;
    
END;

