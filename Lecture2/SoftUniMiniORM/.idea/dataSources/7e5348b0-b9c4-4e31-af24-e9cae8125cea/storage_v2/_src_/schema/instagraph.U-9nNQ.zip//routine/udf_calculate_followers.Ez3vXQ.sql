create
    definer = root@localhost function udf_calculate_followers(user_id int) returns int
BEGIN
	
    DECLARE followers_count INT;
    SET followers_count = (SELECT COUNT(*) FROM users_followers uf WHERE uf.user_id = user_id);
    RETURN followers_count;
    
END;

